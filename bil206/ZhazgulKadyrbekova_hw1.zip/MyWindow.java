import javax.swing.*;
import java.awt.*;

public class MyWindow extends JFrame {
    public MyWindow(String title) throws HeadlessException {
        super(title);
        this.setLayout(null);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(800, 600);

        JMenuBar menuBar = new JMenuBar();

//        JMenu file = new JMenu("File");
//        menuBar.add(file);
//
//        JMenu menu = new JMenu("Menu");
//        menuBar.add(menu);

        JLabel file = new JLabel("File");
        file.setBounds(10, 0, 180, 50);
        this.add(file);

        JLabel menu = new JLabel("Menu");
        menu.setBounds(210, 0, 580, 50);
        this.add(menu);

        JLabel fileName = new JLabel("Text file name");
        fileName.setBounds(10, 100, 180, 50);
        this.add(fileName);

        ButtonGroup group = new ButtonGroup();
        JRadioButton radioButton1 = new JRadioButton("Radio Button 1");
        JRadioButton radioButton2 = new JRadioButton("Radio Button 2");
        JRadioButton radioButton3 = new JRadioButton("Radio Button 3");
        JRadioButton radioButton4 = new JRadioButton("Radio Button 4");
        radioButton1.setBounds(10, 200, 180, 30);
        radioButton2.setBounds(10, 230, 180, 30);
        radioButton3.setBounds(10, 260, 180, 30);
        radioButton4.setBounds(10, 290, 180, 30);
        this.add(radioButton1);
        this.add(radioButton2);
        this.add(radioButton3);
        this.add(radioButton4);
        group.add(radioButton1);
        group.add(radioButton2);
        group.add(radioButton3);
        group.add(radioButton4);
//        this.add(group);

        JTextField textField = new JTextField("Text field");
        textField.setBounds(10, 350, 180, 50);
        this.add(textField);

        JButton submit = new JButton("Submit");
        submit.setBounds(50, 450, 100, 30);
        this.add(submit);

        this.setJMenuBar(menuBar);



    }

    public static void main(String[] args) {
//        MyWindow window =
                new MyWindow("My Window");
    }
}
