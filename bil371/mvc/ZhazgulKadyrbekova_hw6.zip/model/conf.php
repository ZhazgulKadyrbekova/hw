<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbName = "bil371";
?>