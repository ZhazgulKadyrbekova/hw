public interface Australia {
    String name = "Australia";
    String getName();
}
