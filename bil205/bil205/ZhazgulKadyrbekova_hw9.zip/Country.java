public class Country implements Australia{
    private int population;

    public int getPopulation() {
        return population;
    }

    public void setPopulation(int population) {
        this.population = population;
    }

    public String getName() {
        return "Country name:\t" + name;
    }
}
