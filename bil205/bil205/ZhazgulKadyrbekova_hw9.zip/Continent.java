public class Continent implements Australia{
    private int countryNumber;

    public int getCountryNumber() {
        return countryNumber;
    }

    public void setCountryNumber(int countryNumber) {
        this.countryNumber = countryNumber;
    }

    public String getName() {
        return "Continent name:\t" + name;
    }
}
