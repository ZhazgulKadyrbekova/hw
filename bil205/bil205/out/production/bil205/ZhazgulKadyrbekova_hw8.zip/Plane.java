public class Plane extends Transport{
    void move() {
        System.out.println("Fly on a plane");
    }
}
