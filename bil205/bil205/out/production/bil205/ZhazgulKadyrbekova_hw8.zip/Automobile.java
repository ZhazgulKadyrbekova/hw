public class Automobile extends Transport{
    void move() {
        System.out.println("Move by automobile");
    }
}
