public class Bicycle extends Transport{
    void move() {
        System.out.println("Ride a bicycle");
    }
}
