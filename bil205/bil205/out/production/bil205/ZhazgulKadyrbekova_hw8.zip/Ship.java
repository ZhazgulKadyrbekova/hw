public class Ship extends Transport {
    void move() {
        System.out.println("Sail the ship");
    }
}
