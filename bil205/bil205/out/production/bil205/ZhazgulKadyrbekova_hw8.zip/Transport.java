abstract class Transport {
    abstract void move();
}
