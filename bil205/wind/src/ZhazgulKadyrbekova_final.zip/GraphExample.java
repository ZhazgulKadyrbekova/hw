import javax.swing.*;
import java.awt.*;
import java.awt.geom.Line2D;

class GraphExample extends JComponent {
    int start, end;
    int x = 250, y = 100, x1, y1, x2, y2;

    public GraphExample(int start, int end) {
        this.start = start;
        this.end = end;

        this.setLayout(null);
        this.setSize(500, 200);
        this.setVisible(true);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g;

        for (int i = start+1; i <= end; i++) {
            int y = i*i-5;
            x1 = start;
            y1 = start * start - 5;
            x2 = i;
            y2 = i*i - 5;
            g2d.draw(new Line2D.Double(x1, y1, x2, y2));

        }
    }
}