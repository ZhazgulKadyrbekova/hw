using System;
class HW {
	static void Main() {
		int x, y, z; x = 100; y = 1; z = 0;

		Console.WriteLine((x/y != 0) && (x/z != 0));
		//Console.WriteLine((x/y != 0) & (x/z != 0));
	}
}
